#include <stdio.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

//struct Absen untuk membaca dan menulis data dari file
struct Absen{
	int no;
	char nama[50];
	char tanggal[50];
	long long int denda;
	char oleh[50];
};
//struct tabel untuk menampilkan denda
struct Tabel{
	char lambat[50];
	char tidur[50];
	char sakit[50];
	char ijin[50];
	char noket[50];
};
//fungsi untuk membuat / merapikan tabel
void print()
{
    for (int i=0; i<105; i++){
        printf("=");
    }
    printf("\n");
}
//fungsi untuk membuat / merapikan tabel
void cetak()
{
    for (int i=0; i<113; i++){
        printf("=");
    }
    printf("\n");
}
//fungsi untuk memanggil atau membaca isi dari file absen.txt
//akan menampilkan data dari absen.txt jika dipanggil
void baca(struct Absen absen[100]){//memanggil struct Absen dengan nama absen
	system("cls");
	int count = 0;
	FILE *fp;
	//membuka fungsi void baca untuk membaca isi file absen.txt
	fp = fopen("absen.txt", "r");
	while(fscanf(fp,"%d;%[^\';'];%[^\';'];%lld;%[^\n]\n", &absen[count].no, absen[count].nama, absen[count].tanggal, &absen[count].denda, absen[count].oleh) != EOF)
	{
		count++;
	}//menu while diatas untuk membuat perulangan agar bisa membaca isi file absen.txt 
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	printf("%02d-%02d-%d\n\n", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900); //baris 50-52 yaitu untuk menampilkan waktu (tanggal-bulan-tahun)
	print();
	printf("|No#\t|\tNama\t\t|\tTanggal\t\t|\tDenda\t\t|\tOleh\t\t|\n");
	print();
	for (int i=0 ; i<count ; i++){
		printf("|%-4d\t|\t%-12s\t|\t%-12s\t|\t%-12lld\t|\t%-10s\t|\n", absen[i].no, absen[i].nama, absen[i].tanggal, absen[i].denda, absen[i].oleh);
	}//menampilkan isi dari file absen.txt
	print();
	printf("\n");
	fclose(fp);//menutup file atau menutup fungsi void baca
}
//fungsi untuk memanggil atau membaca isi dari file tabel.txt
//akan menampilkan data dari tabel.txt jika dipanggil
void read(struct Tabel tabel[100]){//memanggil struct Tabel dengan nama tabel
	system("cls");
	struct Absen absen[100];
	int count = 0;
	FILE *fp;
	//membuka fungsi void baca untuk membaca isi file tabel.txt
	fp = fopen("tabel.txt", "r");
	while(fscanf(fp,"%[^\';'];%[^\';'];%[^\';'];%[^\';'];%[^\n]\n", tabel[count].lambat, tabel[count].tidur, tabel[count].sakit, tabel[count].ijin, tabel[count].noket) != EOF)
	{
		count++;
	}//menu while diatas untuk membuat perulangan agar bisa membaca isi file tabel.txt sampai EOF atau file berakhir
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	printf("%02d-%02d-%d\n\n", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900); //baris 74-76 yaitu untuk menampilkan waktu (tanggal-bulan-tahun)
	baca(absen);
	printf("Tabel Denda\n");
	cetak();
	printf("|Terlambat\t|\tKetiduran\t|\tSakit\t\t|\tIzin\t\t|\tTanpa Keterangan|\n");
	cetak();
	for (int i=0 ; i<count ; i++){
		printf("|%-10s\t|\t%-12s\t|\t%-12s\t|\t%-12s\t|\t%-10s\t|\n", tabel[i].lambat, tabel[i].tidur, tabel[i].sakit, tabel[i].ijin, tabel[i].noket);
	}//menampilkan isi dari file tabel.txt
	cetak();
	printf("\n");
	fclose(fp);//menutup file atau menutup fungsi void read
}
//fungsi untuk menulis atau menginput data ke file absen.txt
void tulis(struct Absen absen[100]){//memanggil struct Absen dengan nama absen
	system("cls");
	struct Tabel tabel[100];
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);//fungsi untuk menampilkan waktu
	int count = 0;
	FILE *fp;
	
	fp = fopen("absen.txt","r");//membuka/membaca file absen.txt
	while(fscanf(fp,"%d;%[^\';'];%[^\';'];%lld;%[^\n]\n", &absen[count].no, absen[count].nama, absen[count].tanggal, &absen[count].denda, absen[count].oleh) != EOF){
		count++;
	}//menu while diatas untuk membuat perulangan agar bisa membaca isi file absen.txt sampai akhir file
	fclose(fp); //menampilkan  
	read(tabel);
	fp = fopen("absen.txt","a");
	//untuk baris 106-118 user bisa memasukkan data untuk disimpan di file absen.txt
	printf("Add Data\n");
	printf("Masukkan Nomor : ");
	scanf("%d", &absen->no);
	getchar();
	printf("Masukkan Nama : ");
	scanf("%[^\n]", absen->nama);
	getchar();
	printf("Masukkan Denda : ");
	scanf("%lld", &absen->denda);
	getchar();
	printf("Data dimasukan oleh : ");
	scanf("%[^\n]", absen->oleh);
	getchar();
	(count == 0) ? fprintf(fp,"%d;%s;%02d-%02d-%d;%lld;%s", absen->no, absen->nama, tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900, absen->denda, absen->oleh) :
				fprintf(fp,"\n%d;%s;%02d-%02d-%d;%lld;%s", absen->no, absen->nama, tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900, absen->denda, absen->oleh);
		printf("Data Added!\n");//pada baris 83 dan 84 data sudah di simpan pada file
		system("pause");
		system("cls");
	fclose(fp);
}
//fungsi untuk menghapus data perbaris dengan menginput nomor baris yang ingin dihapus
void hapus(struct Absen absen[100]){//memanggil struct Absen dengan nama absen
	system("cls");
	FILE *fp;
	int count = 0;
	
	fp = fopen("absen.txt","r");//membuka/membaca file absen.txt
	while(fscanf(fp,"%d;%[^\';'];%[^\';'];%lld;%[^\n]\n", &absen[count].no, absen[count].nama, absen[count].tanggal, &absen[count].denda, absen[count].oleh) != EOF){
		count++;
	}//menu while diatas untuk membuat perulangan agar bisa membaca isi file absen.txt sampai akhir file
	fclose(fp);
	int delete;
	baca(absen);//menampilkan data pada file untuk memudahkan memilih pilhan yang ada pada fungsi hapus
	printf("Masukkan Nomor yang ingin dihapus : ");
	scanf("%d", &delete); getchar();//menginput dan scan hasil inputan
	int deletekey = -1;
	fp = fopen("absen.txt", "w");//menulis atau melakukan perubahan pada file 
	for (int i=0; i<count; i++){
		if(absen[i].no==delete){
			deletekey=i;
			continue;//jika inputan user cocok dengan data nama pada file absen.txt maka nomor itu beserta 1 barisnya akan di skip(terhapus) dari file
		}
		else{
			fprintf(fp,"%d;%s;%s;%lld;%s\n", absen[i].no, absen[i].nama, absen[i].tanggal, absen[i].denda, absen[i].oleh);
		}
	}
		if(deletekey != -1){
			printf("berhasil dihapus\n");//jika inputan user cocok atau sesuai dengan data yang ada pada file maka akan keluar output ini
			system("pause");
			system("cls");
		}
		else{
			printf("Nomor tidak ditemukan\n");//jika inputan user tidak ada yang cocok/sesuai dengan data makan akan keluar output ini
			system("pause");
			system("cls");
		}
	fclose(fp);
} 
//fungsi untuk memperbarui data
void perbarui(struct Absen absen[100]){//memanggil struct Absen dengan nama absen
	system("cls");
	struct Tabel tabel[100];
	FILE *fp;
	int count = 0;
	
		fp = fopen("absen.txt","r");
	while(fscanf(fp,"%d;%[^\';'];%[^\';'];%lld;%[^\n]\n", &absen[count].no, absen[count].nama, absen[count].tanggal, &absen[count].denda, absen[count].oleh) != EOF){
		count++;
	}//menu while diatas untuk membuat perulangan agar bisa membaca isi file absen.txt sampai akhir file
	fclose(fp);
	read(tabel);//memanggil fungsi read untuk mempermudah user untuk memilih pilihan 
	
	fp = fopen("absen.txt", "w");
	time_t t = time(NULL);
	struct tm tm = *localtime(&t); 
	int noPerbarui;
	int perbaruiKey = -1;
	printf("Masukkan Nomor yang akan di perbarui : ");
	scanf("%d", &noPerbarui); getchar();//menginput variabel nomor yang akan di perbarui
	for (int i = 0; i < count; i++){
		if (absen[i].no == noPerbarui){
			perbaruiKey = i;
			printf("Masukkan Nomer baru : ");
			scanf("%d", &absen[perbaruiKey].no);
			getchar();
			printf("Masukkan Nama baru : ");
			scanf("%[^\n]", absen[perbaruiKey].nama);
			getchar();
			printf("Masukkan Denda baru : ");
			scanf("%lld", &absen[perbaruiKey].denda);
			getchar();
			printf("Masukkan Pembuat yang baru : ");
			scanf("%[^\n]", absen[perbaruiKey].oleh);
			getchar();//memasukkan data yang akan di perbarui 
			fprintf(fp,"%d;%s;%02d-%02d-%d;%lld;%s\n", absen[i].no, absen[i].nama, tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900, absen[i].denda, absen[i].oleh);
		}
		else{
			fprintf(fp,"%d;%s;%02d-%02d-%d;%lld;%s\n", absen[i].no, absen[i].nama, tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900, absen[i].denda, absen[i].oleh);
		}//memperbarui data pada file
	}
	if(perbaruiKey == -1){
		printf("Nomor tidak ditemukan!\n");//jika variabel yang diinput tidak sesuai/cocok dengan isi file maka akan keluar output ini
		system("pause");
		system("cls");
	}
	else{
		printf("Data berhasil Diperbarui\n");//jika variuabel yang diinput sesuai/cocok dengan isi file maka akan keluar output ini
		system("pause");
		system("cls");
	}
	fclose(fp);
}
//fungsi untuk mecari dan memanggil nama 
void searchByName(struct Absen absen[100]){
	system("cls");
	FILE *fp;
	int count=0;
	
	fp = fopen("absen.txt","r");
	while(fscanf(fp,"%d;%[^\';'];%[^\';'];%lld;%[^\n]\n", &absen[count].no, absen[count].nama, absen[count].tanggal, &absen[count].denda, absen[count].oleh) != EOF){
		count++;
	}
	char searchnama[15];
	int searchNama;
	int sNamaKey = -1;
	printf("Masukkan Nama yang ingin dicari : ");
	scanf("%s", searchnama);//manginput nama yang akan dicari
	getchar();
		print();
		printf("|No#\t|\tNama\t\t|\tTanggal\t\t|\tDenda\t\t|\tOleh\t\t|\n"); 
		print();
	int i;
	for (i=0; i<count; i++){
			if(strcmpi(absen[i].nama,searchnama)==0){
			sNamaKey = i;
			printf("|%-4d\t|\t%-12s\t|\t%-12s\t|\t%-12lld\t|\t%-10s\t|\n", absen[i].no, absen[i].nama, absen[i].tanggal, absen[i].denda, absen[i].oleh);
			}//memanggil nama dan semua data yang bersama dengan nama yang diinput 
	}
	print();
	if(sNamaKey == -1){
		printf("Nama tidak ditemukan!\n");//jika varibel nama yang diinput tidak sesuai/cocok dengan isi file makan akan keluar output ini
	}
	printf("\n"); 
	fclose(fp);
	
}
void searchByWaktu(struct Absen absen[100]){
	system("cls");
	FILE *fp;
	int count=0;
	
	fp = fopen("absen.txt","r");
	while(fscanf(fp,"%d;%[^\';'];%[^\';'];%lld;%[^\n]\n", &absen[count].no, absen[count].nama, absen[count].tanggal, &absen[count].denda, absen[count].oleh) != EOF){
		count++;
	}
	char searchtanggal[15];
	int searchTanggal;
	int sTanggalKey = -1;
	printf("Masukkan Tanggal yang ingin dicari : ");
	scanf("%[^\n]", searchtanggal);//manginput tanggal yang akan dicari
	getchar();
		print();
		printf("|No#\t|\tNama\t\t|\tTanggal\t\t|\tDenda\t\t|\tOleh\t\t|\n"); 
		print();
	int i;
	for (i=0; i<count; i++){
			if(strcmpi(absen[i].tanggal,searchtanggal)==0){
			sTanggalKey = i;
			printf("|%-4d\t|\t%-12s\t|\t%-12s\t|\t%-12lld\t|\t%-10s\t|\n", absen[i].no, absen[i].nama, absen[i].tanggal, absen[i].denda, absen[i].oleh);
			}//memanggil waktu dan semua data yang bersama dengan waktu yang diinput 
	}
	print();
	if(sTanggalKey == -1){
		printf("Tanggal tidak ditemukan!\n");//jika varibel waktu yang diinput tidak sesuai/cocok dengan isi file makan akan keluar output ini
	}
	printf("\n"); 
	fclose(fp);
	
}
//fungsi untuk mencari dan memanggil pembuat
void searchByOleh(struct Absen absen[100]){
	system("cls");
	FILE *fp;
	int count=0;
	
	fp = fopen("absen.txt","r");
	while(fscanf(fp,"%d;%[^\';'];%[^\';'];%lld;%[^\n]\n", &absen[count].no, absen[count].nama, absen[count].tanggal, &absen[count].denda, absen[count].oleh) != EOF){
		count++;
	}
	char searchnama[15];
	int searchNama;
	int sNamaKey = -1;
	printf("Masukkan Nama yang ingin dicari : ");
	scanf("%s", searchnama);//menginput pembuat yang ingin dicari
	getchar();
		print();
		printf("|No#\t|\tNama\t\t|\tTanggal\t\t|\tDenda\t\t|\tOleh\t\t|\n"); 
		print();
	int i;
	for (i=0; i<count; i++){
			if(strcmpi(absen[i].oleh,searchnama)==0){
			sNamaKey = i;
			printf("|%-4d\t|\t%-12s\t|\t%-12s\t|\t%-12lld\t|\t%-10s\t|\n", absen[i].no, absen[i].nama, absen[i].tanggal, absen[i].denda, absen[i].oleh);
			}//memanggil nama dan semua data yang bersama dengan nama yang diinput
	}
	print();
	if(sNamaKey == -1){
		printf("Pembuat tidak ditemukan!\n");//jika varibel pembuat yang diinput tidak sesuai/cocok dengan isi file makan akan keluar output ini
	}
	printf("\n"); 
	fclose(fp);
}
//fungsi untk mengurutkan nama
void sortByName(struct Absen absen[100]) {
    system("cls");
    struct Absen temp;
    FILE *fp;
    fp=fopen("absen.txt", "r");
    int count = 0;
    while(fscanf(fp,"%d;%[^\';'];%[^\';'];%lld;%[^\n]\n", &absen[count].no, absen[count].nama, absen[count].tanggal, &absen[count].denda, absen[count].oleh) != EOF){
		count++;
	}
    char tempChar[100];
    int tempInt;
    for(int i=0;i<count;i++){
        for(int j=i+1;j<count;j++){
            if(strcmp(absen[i].nama, absen[j].nama)>0){
                temp=absen[i];
                absen[i]=absen[j];
                absen[j]=temp;//fungsi dari baris 260-265 menukarkan varibel nama setiap 2 baris pada file,mengurutkan alphabet yang lebih awal akan di tukar menjadi diatas dan yang lebih akhir akan ditukar dibawah
            }
        }
    }
    printf("Mengurutkan Berdasarkan Nama\n");
   	print();
	printf("|No#\t|\tNama\t\t|\tTanggal\t\t|\tDenda\t\t|\tOleh\t\t|\n");
	print();
    for(int i=0 ; i<count ;i++){
        printf("|%-4d\t|\t%-12s\t|\t%-12s\t|\t%-12lld\t|\t%-10s\t|\n", absen[i].no, absen[i].nama, absen[i].tanggal, absen[i].denda, absen[i].oleh);
    }
    print();//menampilkan urutan data sesuai dengan urutan nama mulai dari yang paling rendah/awal
    printf("\n");
}
//mengurutkan data sesuai dengan waktunya(tanggal)
void sortByDate(struct Absen absen[100]) {
    system("cls");
    struct Absen temp;
    FILE *fp;
    fp=fopen("absen.txt", "r");
    int count = 0;
    while(fscanf(fp,"%d;%[^\';'];%[^\';'];%lld;%[^\n]\n", &absen[count].no, absen[count].nama, absen[count].tanggal, &absen[count].denda, absen[count].oleh) != EOF){
		count++;
	}
    char tempChar[100];
    int tempInt;
    for(int i=0;i<count;i++){
        for(int j=i+1;j<count;j++){
            if(strcmp(absen[i].tanggal, absen[j].tanggal)<0){
                temp=absen[i];
                absen[i]=absen[j];
                absen[j]=temp;//dari baris 290-295 mengurutkan data pada file sesuai dengan waktu data dibuat
            }
        }
    }
    printf("Mengurutkan Berdasarkan Tanggal terbaru\n");
   	print();
	printf("|No#\t|\tNama\t\t|\tTanggal\t\t|\tDenda\t\t|\tOleh\t\t|\n");
	print();
    for(int i=0 ; i<count ;i++){
        printf("|%-4d\t|\t%-12s\t|\t%-12s\t|\t%-12lld\t|\t%-10s\t|\n", absen[i].no, absen[i].nama, absen[i].tanggal, absen[i].denda, absen[i].oleh);
    }//menampilakn data sesuai dengan waktunya dibuat
    print();
    printf("\n");
}
//fungsi untk mengurutkan nama
void sortByOleh(struct Absen absen[100]) {
    system("cls");
    struct Absen temp;
    FILE *fp;
    fp=fopen("absen.txt", "r");
    int count = 0;
    while(fscanf(fp,"%d;%[^\';'];%[^\';'];%lld;%[^\n]\n", &absen[count].no, absen[count].nama, absen[count].tanggal, &absen[count].denda, absen[count].oleh) != EOF){
		count++;
	}
    char tempChar[100];
    int tempInt;
    for(int i=0;i<count;i++){
        for(int j=i+1;j<count;j++){
            if(strcmp(absen[i].oleh, absen[j].oleh)>0){
                temp=absen[i];
                absen[i]=absen[j];
                absen[j]=temp;//fungsi dari baris 320-325 menukarkan varibel nama setiap 2 baris pada file,mengurutkan alphabet yang lebih awal akan di tukar menjadi diatas dan yang lebih akhir akan ditukar dibawah
            }
        }
    }
    printf("Mengurutkan berdasarkan Nama Pembuat\n");
   	print();
	printf("|No#\t|\tNama\t\t|\tTanggal\t\t|\tDenda\t\t|\tOleh\t\t|\n");
	print();
    for(int i=0 ; i<count ;i++){
        printf("|%-4d\t|\t%-12s\t|\t%-12s\t|\t%-12lld\t|\t%-10s\t|\n", absen[i].no, absen[i].nama, absen[i].tanggal, absen[i].denda, absen[i].oleh);
    }
    print();//menampilkan urutan data sesuai dengan urutan pembuat/oleh mulai dari yang paling rendah/awal
    printf("\n");
}
//fungsi untuk menampilkan menu cari/search
//untuk search saya menggunakan linear search dimana jika inputan dari user sama dengan data dari file absen.txt maka akan memanggil data tersebut pada program
void search(struct Absen absen[100])
{
	system("cls");
    FILE *fp;
    fp=fopen("absen.txt", "r");
    int input;
    do{
    	printf("Pencarian Data\n");//pada menu search terdapat 3 pilihan untuk mencari berdasarkan nama dan pembuat dan menu 3 mengmbalikan user ke menu utama
    	printf("1. Cari Nama\n");
    	printf("2. Cari Waktu/Tanggal dibuat\n");
    	printf("3. Cari Nama Pembuat\n");
    	printf("4. Exit\n");
    	printf("Select Menu (1/2/3/4) : ");
    	scanf("%d", &input); getchar();//user memasukkan menu yang akan dipilih
    	switch(input)
    	{
    		case 1: //nomor 1 menampilkan/memanggil fungsi cari nama
    			searchByName(absen);
            	system("pause");
            	system("cls");
            	break;
            case 2:
            	searchByWaktu(absen);//nomor 2 menampilkan/memanggil fungsi cari waktu/tanggal
            	system("pause");
            	system("cls");
            	break;
            case 3://nomor 3 menampilkan/memanggil fungsi cari pembuat/oleh
            	searchByOleh(absen);
            	system("pause");
            	system("cls");
            	break;
		}
	}while(input >=1 && input <4);//while disini berfungsi untuk mengembalikan user ke menu utama jika menginput variabel lebih dari angka 3
fclose(fp);
}
//fungsi untuk menampilkan menu mengurutkan
//untuk sorting saya menggunakan bubble sort dengan mengoperasikan index ke i dan j
void sort(struct Absen absen[100])
{
	system("cls");
    FILE *fp;
    fp=fopen("absen.txt", "r");
    int input;
    do{
    	printf("Pengurutan Data\n");//pada menu sort terdapat 3 pilihan untuk mengurutkan berdasarkan nama dan waktu(tanggal) dan menu 3 mengmbalikan user ke menu utama
    	printf("1. Urutkan Nama\n");
    	printf("2. Urutkan Tanggal\n");
    	printf("3. Urutkan Pembuat\n");
    	printf("4. Exit\n");
    	printf("Select Menu (1/2/3) : ");
    	scanf("%d", &input); getchar();//user memasukkan menu yang akan dipilih
    	switch(input)
    	{
    		case 1://nomor 1 menampilkan/memanggil fungsi mngurutkan nama
    			sortByName(absen);
            	system("pause");
            	system("cls");
            	break;
            case 2://nomor 2 menampilkan/memanggil fungsi mengurutkan berdasarkan waktu(tanggal)
            	sortByDate(absen);
            	system("pause");
            	system("cls");
            	break;
            case 3:
            	sortByOleh(absen);//nomor 3 menampilkan/memanggil fungsi mengurutkan berdasarkan pembuat/oleh
            	system("pause");
            	system("cls");
            	break;
		}
	}while(input >=1 && input <4);//while disini berfungsi untuk mengembalikan user ke menu utama jika menginput variabel lebih dari angka 3
fclose(fp);
}
//menu utama 
int main(){
	struct Absen absen[100];
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);//fungsi untuk menampilkan waktu(tanggal-bulan-tahun)
	int input;
	int inputuser;
    char pw[8];
    char pw1[6];
    do{
        system("cls");
        printf("%02d-%02d-%d\n\n", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
    	printf("Data Absensi Pemuda Banjar Penestanan Kaja\n");//menu pertama yang diperlihatkan pada program yaitu menu Login
        printf("Menu Login\n");
    	printf("1. Login\n");
    	printf("2. Exit\n");
    	printf("Select (1/2): ");
    	scanf("%d", &inputuser);//user memasukkan menu yang akan dipilih
    	switch(inputuser)
    	{
    		case 1://menu 1 user akan login pada program dan harus memasukkan password untuk menuju menu utama
    			system("cls");
    			printf("(password=login)\n");
    		printf ("Enter Password : ");//user disini menginput password yang benar
			fflush(stdin);
			
			char ch;
			int i = 0;
			while((ch = (char) _getch()) != '\r'){
				pw[i]  = ch;
				printf("*");//baris 394-398 untuk menyensor inputan user dengan tanda bintang
				i++;
			}printf("\n");
			if (strcmpi(pw,"login")==0)
			{
				printf ("Login Successfully\n");//jika user menginput password dengan benar makan akan keluar output sebagai berikut dan dipindahkan ke menu utama
			}
			else
			{
				printf("Wrong Password!\n");//jika user menginput password salah makan akan keluar output sebagai berikut
				printf("Input Password one more time : ");//user akan diberikan kesempatan sekali lagi untuk menginput password 
				fflush(stdin);
			
			char ch;
			int i = 0;
			while((ch = (char) _getch()) != '\r'){
				pw1[i]  = ch;
				printf("*");
				i++;
			}printf("\n");
					if (strcmpi(pw1,"login")==0)
					{
						printf ("Login Successfully\n");
					}
					else{
						printf("Wrong Password!!!\n");
						return 0;//jika inputan user salah lagi makan user akan keluar dari menu dan program berakhir
					}
			}
			system("pause");
	do{
		 system("cls");
        printf("%02d-%02d-%d\n\n", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
        printf("Menu Utama\n");//pada menu utama user akan diberikan 7 pilihan
        printf("1. Baca\n");
        printf("2. Tulis\n");
        printf("3. Hapus\n");
        printf("4. Perbarui\n");
        printf("5. Cari\n");
        printf("6. Urut\n");
        printf("7. Exit\n");
        printf("Pilih Menu (1/2/3/4/5/6/7): ");
        scanf("%d", &input);//user menginput pilihan yang dipilih
		switch(input){
		case 1://nomor 1 akan memanmggil fungsi baca
			baca(absen);
			system("pause");
			system("cls");
			break;
		case 2://nomnor 2 akan memanggil fungsi tulis
			tulis(absen);
			break;
		case 3://nomor 3 akan memanggil fungsi hapus
			hapus(absen);
			break;
		case 4://nomor 4 akan memanggil fungsi perbarui
			perbarui(absen);
			break;
		case 5://nomor 5 akan menampilkan fungsi cari/search
			search(absen);
			system("pause");
            system("cls");
			break;
		case 6://nomor 6 akakn menampilkan fungsi sort/mengurutkan 
			sort(absen);
			system("pause");
            system("cls");
            break;
        default:
        	break;
		}
		}while(input >=1 && input <7);//while disini untuk mengembalikan user ke menu login jika user menginput lebih dari angka 6 pada menu utama
	}
	}while(inputuser >0 && inputuser <2);//while ini berfungsi untuk mengakhiri program jika user menginput lebih dari angka 1 pada menu login
    return 0;
}
